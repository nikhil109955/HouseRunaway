const loader = new THREE.TextureLoader();

let texture= loader.load('./textures/sphere/sun.jpg', function(texture){
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.offset.set( 0, 0 );
    texture.repeat.set( 2, 2 );
});
const geometry = new THREE.SphereGeometry( 300, 32, 16 );
const material = new THREE.MeshBasicMaterial( { map: texture } );
const sphere = new THREE.Mesh( geometry, material );
sphere.position.set(-2048,30,-2048);
sphere.castShadow = true; //default is false
sphere.receiveShadow = false;
const hemiLight = new THREE.HemisphereLight( 0xffffff, 0xffffff, 0.8 );
hemiLight.position.set(-2048,30,-2048);
const pointLight = new THREE.PointLight( 0xffffff, 1.2, 3000 );
pointLight.position.set(-2048,30,-2048);
pointLight.castShadow = true; // default false
pointLight.shadow.mapSize.width = 512; // default
pointLight.shadow.mapSize.height = 512; // default
pointLight.shadow.camera.near = 0.5; // default
pointLight.shadow.camera.far = 500; // default

let sunGroup = new THREE.Group();
sunGroup.add(sphere);
sunGroup.add(hemiLight);
sunGroup.add(pointLight);

export let sun = sunGroup;